#!/bin/bash

FILE="/tmp/communication.txt"
touch FILE
